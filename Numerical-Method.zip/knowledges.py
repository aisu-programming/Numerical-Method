import math

# e
print(math.e)

# sin & pi
print(math.sin(math.pi / 2))

# cube root
print(27 ** (1./3.))

# logn (ln)
print(math.log(math.e))